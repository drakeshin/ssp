//
//  Contas.swift
//  Speeding
//
//  Created by Student on 4/26/16.
//  Copyright © 2016 SpeedCode. All rights reserved.
//

import Foundation


class Contas
{

    private var nome:String?
    private var sobreNome:String?
    private var id:String?
    private var registroRg:Int?
    private var registroCpf:Int?
    private var endereco:String?
    private var endeNum:Int?
    private var endCep:Int?
    
}