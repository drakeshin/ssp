//
//  Registro.swift
//  Speeding
//
//  Created by Student on 4/27/16.
//  Copyright © 2016 SpeedCode. All rights reserved.
//

import UIKit

class Registro: UIViewController {
    @IBOutlet weak var nome: UITextField!
    @IBOutlet weak var sobrenome: UITextField!
    @IBOutlet weak var cep: UITextField!
    @IBOutlet weak var rg: UITextField!
    @IBOutlet weak var cpf: UITextField!
    @IBOutlet weak var endereco: UITextField!
    @IBOutlet weak var telefone: UITextField!
    @IBOutlet weak var user: UITextField!
    @IBOutlet weak var passwd: UITextField!
    
    public var nomeV:String?
    public var sobrenomeV:String?
    public var cepV:String?
    public var rgV:String?
    public var cpfV:String?
    public var enderecoV:String?
    public var telefoneV:String?
    public var userV:String?
    public var passwdV:String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func registro(sender: AnyObject) {
        nomeV = nome.text
        sobrenomeV = sobrenome.text
        cepV = cep.text
        rgV = rg.text
        cpfV = cpf.text
        enderecoV = endereco.text
        telefoneV = telefone.text
        userV = user.text
        passwdV = passwd.text
        
        nome.text = nil
        sobrenome.text = nil
        cep.text = nil
        rg.text = nil
        cpf.text = nil
        endereco.text = nil
        telefone.text = nil
        user.text = nil
        passwd.text = nil
        
        ///self.navigationController?.popToViewController(vc, animated: true)
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
    
    
    

}
